package com.invoice.invoiceprocessingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoiceprocessingsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvoiceprocessingsystemApplication.class, args);
	}

}
